<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'brain-stages-dev');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '|dAznQ,`+=`#s+QJD@kb _9qk3@7#-4az%D*qh,KT[*:-kbp9?sb7<>vR1uYY`du');
define('SECURE_AUTH_KEY',  'Wku0iJYLbJ#7k-tJ0$^Psi-oP?#?/?YYuQN.w|b-NUo?-*~rmV~wZ/jxjWf[#zoI');
define('LOGGED_IN_KEY',    'AW/Z9ZqT1J.I!B$(lh.<@/_=t)(#NbYPJHOF*CPq?CR+Q|fc_%N &QtJR2nIj?-/');
define('NONCE_KEY',        '^Oo`M>=##k%#|UgR0b?rRA}P)#N_0xF45% %R-2ONnl<8- ]39,LuMA5`d?T-T,4');
define('AUTH_SALT',        'fu.:.v&0+0JK?*2}+Zzu:nvbN=,/fi{sp%{k{/B$(%!j-m%|MlPUMa4$TYW3 +:=');
define('SECURE_AUTH_SALT', 'pRDA)4=Ypj.65rk<1+lrY3Xx}W8}G6dOp%&3<5A96IP1EZ20$4Z<)1s!UDXOt/| ');
define('LOGGED_IN_SALT',   'b6UjUj6x}*6n6lfmhzeR649L,Zp={IF|!4AG`68pm%X}WnhF>4zX,HH0H] 4|T)>');
define('NONCE_SALT',       'I8-_wtw_l2b1w2=0_u=::`VW+ltiJAB;A^NxT1@;IXjo|p~yh)pOmE[nx?QP-_sw');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'tbstw_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
